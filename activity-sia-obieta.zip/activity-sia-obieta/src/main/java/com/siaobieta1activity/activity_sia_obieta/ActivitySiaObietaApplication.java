package com.siaobieta1activity.activity_sia_obieta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivitySiaObietaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivitySiaObietaApplication.class, args);
	}

	

}
