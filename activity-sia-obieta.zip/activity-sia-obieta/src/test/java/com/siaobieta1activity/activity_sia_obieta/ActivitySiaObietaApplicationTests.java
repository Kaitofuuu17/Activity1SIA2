package com.siaobieta1activity.activity_sia_obieta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivitySiaObietaApplicationTests {

	@Test
	void contextLoads() {
	}

}
